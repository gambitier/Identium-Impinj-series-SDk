package demo.stand;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.swing.JOptionPane;

import com.uhf.api.cls.ErrInfo;
import com.uhf.api.cls.R2000_calibration;
import com.uhf.api.cls.ReadListener;
import com.uhf.api.cls.Reader;
import com.uhf.api.cls.Reader.*;

/**
 * ����API���ֽӿ�
 * @author Administrator
 *
 */
public class maintest_std extends Thread {

	/**
	 * @param args
	 */

	//int AntCount = 4;
	//String ReaderAddr = "192.168.1.100";
	//String ReaderAddr = "com4:921600";
	int AntCount = 1;
	String ReaderAddr = "com4";
	
	Reader Jreader;

	int Id = 0;
	//
	Map<String, Tagandtime> TagsMap = new LinkedHashMap<String, Tagandtime>();

	public class Tagandtime {
		public TAGINFO taginfo;
		public long time;
	}

	public maintest_std() {
		Jreader = new Reader();

	}

	// ת���������������ַ���ת�ֽ����飬16�����ַ���ת�ֽ�����
	public void testtran() {
		byte[] hex = new byte[] { (byte) 0xA2, (byte) 0xC8, (byte) 0xD4, (byte) 0xE5 };
		int len = 4;
		char[] str = new char[4 * 2];
		Jreader.Hex2Str(hex, len, str);
		String hstr = "";
		for (int i = 0; i < 8; i++)
			hstr += (char) str[i];
		System.out.println("test tohexstr:" + hstr);

		String buf = "0011110000001111";

		byte[] binarybuf = new byte[2];
		String buf2 = "abcdef08";
		byte[] hexbuf = new byte[4];
		Jreader.Str2Binary(buf, buf.length(), binarybuf);
		System.out.println("test binary:");
		for (int i = 0; i < binarybuf.length; i++)
			System.out.println(binarybuf[i]);

		Jreader.Str2Hex(buf2, 8, hexbuf);
		System.out.println("test hex:");
		for (int i = 0; i < hexbuf.length; i++)
			System.out.println(hexbuf[i]);
	}

	// ����psam��
	public void testpsam() {
		int soltid = 1;
		int coslen = 2;
		byte[] cos = new byte[] { 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, (byte) 0x88, (byte) 0x99, 0x12, 0x34 };
		int[] cosresplen = new int[1];
		byte[] cosresp = new byte[cos.length + 13];
		byte[] errcode = new byte[4];

		READER_ERR er = Jreader.PsamTransceiver(soltid, coslen, cos, cosresplen, cosresp, errcode, (short) 1000);
	}

	/**
	 * ���������ǩ����
	 */
	public void testcustomcmd() {
		TagFilter_ST tfst = Jreader.new TagFilter_ST();
		tfst.bank = 1;
		tfst.fdata = new byte[] { (byte) 0x11, (byte) 0xc0 };
		// flen 0 Ϊȡ������
		tfst.flen = 12;
		tfst.isInvert = 0;
		tfst.startaddr = 32;

		Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_FILTER, tfst);
		// m4 qt
		IMPINJM4QtPara CustomPara = Jreader.new IMPINJM4QtPara();
		CustomPara.TimeOut = 1000;
		CustomPara.CmdType = 1;
		if (CustomPara.CmdType == 1) {
			CustomPara.MemType = 1;
			CustomPara.PersistType = 0;
			CustomPara.RangeType = 1;
		}
		CustomPara.AccessPwd = new byte[] { 0x22, 0x22, 0x11, 0x11 };

		IMPINJM4QtResult CustomRet = Jreader.new IMPINJM4QtResult();
		Jreader.CustomCmd(1, CustomCmdType.IMPINJ_M4_Qt, CustomPara, CustomRet);

		// allen h3
		ALIENHiggs3BlockReadLockPara CustomPara2 = Jreader.new ALIENHiggs3BlockReadLockPara();
		CustomPara2.AccessPwd = new byte[] { 0x55, 0x66, 0x77, (byte) 0x88 };
		CustomPara2.BlkBits = 6;
		CustomPara2.TimeOut = 890;
		Jreader.CustomCmd(1, CustomCmdType.ALIEN_Higgs3_BlockReadLock, CustomPara2, null);

		// nexp eas
		NXPChangeEASPara CustomPara3 = Jreader.new NXPChangeEASPara();
		CustomPara3.AccessPwd = new byte[] { (byte) 0x99, (byte) 0xaa, (byte) 0xbb, (byte) 0xcc };
		CustomPara3.isSet = 1;
		CustomPara3.TimeOut = 900;
		Jreader.CustomCmd(1, CustomCmdType.NXP_ChangeEAS, CustomPara3, null);

		// nxp easl
		NXPEASAlarmPara CustomPara4 = Jreader.new NXPEASAlarmPara();
		CustomPara4.DR = 7;
		CustomPara4.MC = 11;
		CustomPara4.TimeOut = 950;
		CustomPara4.TrExt = 17;

		NXPEASAlarmResult CustomRet2 = Jreader.new NXPEASAlarmResult();
		Jreader.CustomCmd(1, CustomCmdType.NXP_EASAlarm, CustomPara4, CustomRet2);

		// basetype
		Jreader.CustomCmd_BaseType(1, 1, new byte[] { 0x11, (byte) 0x99, (byte) 0xbb }, new byte[] {});

	}

	/**
	 * ���Թ��˶�д��ǩ
	 */
	public void testfilterwirteandread()
	{
		// �����Ա�ǩ��TID��Ϊ�������������Ժ�ı�ǩ����
				TagFilter_ST tfst = Jreader.new TagFilter_ST();
				tfst.bank = 1;
				tfst.fdata = new byte[]{0x00,0x00,0x00,0x7E,0x70,(byte) 0xC3,0x46,
						(byte) 0x85,0x00,0x00,0x00,0x00};
				tfst.flen = tfst.fdata.length*8;
				tfst.isInvert = 0;
				tfst.startaddr = 32;

				Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_FILTER, tfst);
				
				byte[] data = new byte[] { 0x22, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, (byte) 0x88, (byte) 0x99,
						(byte) 0xaa, (byte) 0xbb };
				//д����
				READER_ERR er = Jreader.WriteTagData(1, (char) 3, 3840, data, data.length, null, (short) 1000);
				System.out.println("write1:" + er.toString());
				
				byte[] datar = new byte[data.length];
				 
				er = Jreader.GetTagData(1, (char) 3, 3840, data.length/2, datar, null, (short) 1000);
				String str1 = "";
				if (er == READER_ERR.MT_OK_ERR)
					str1 = Jreader.bytes_Hexstr(datar);

				System.out.println(er.toString() + " " + str1.toUpperCase());
	
				Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_FILTER, null);
	}
	
	/**
	 * ���Զ�д��ǩ
	 */
	public void testreadandwrite() {
		/*
		 * READER_ERR WriteTagData(int ant,char bank,int address, byte[] data,
		 * int datalen, byte[] accesspasswd,short timeout); ant �����ĵ����� bank ��ʾ����
		 * 0��ʾ������ 1��ʾepc�� 2��ʾtid�� 3��ʾuser�� address ��ʾ��ַ�飬 ע��epc���ӵڶ��鿪ʼ data д������
		 * datalen ��ʾд�����ݳ��� accesspwd ��ʾ���룬Ĭ��"00000000" 8��ʮ�������ַ� timeout ������ʱʱ��
		 */

		String pwd = "00000000";
		byte[] data = new byte[] { 0x22, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, (byte) 0x88, (byte) 0x99,
				(byte) 0xaa, (byte) 0xbb };
		byte[] pwdb = new byte[4];
		Jreader.Str2Hex(pwd, pwd.length(), pwdb);
		// д����
		READER_ERR er = Jreader.WriteTagData(1, (char) 1, 2, data, 12, null, (short) 1000);
		System.out.println("write1:" + er.toString());
		byte[] datar = new byte[12];
		// ������
		/*
		 * READER_ERR GetTagData(int ant,char bank, int address, int
		 * blkcnt,byte[] data, byte[] accesspasswd, short timeout); ant �����ĵ�����
		 * bank ��ʾ���� 0��ʾ������ 1��ʾepc�� 2��ʾtid�� 3��ʾuser�� address ��ʾ��ַ�飬 ע��epc���ӵڶ��鿪ʼ
		 * blkcnt ��ʾ������ data ������ݵ��ֽڣ�Ӧ�ò�С��blkcnt*2 accesspwd ��ʾ���룬Ĭ��"00000000",��Ĭ�Ͽɴ�null
		 * 8��ʮ�������ַ� timeout ������ʱʱ��
		 */
		er = Jreader.GetTagData(1, (char) 1, 2, 6, datar, null, (short) 1000);
		String str1 = "";
		if (er == READER_ERR.MT_OK_ERR)
			str1 = Jreader.bytes_Hexstr(datar);

		System.out.println(er.toString() + " " + str1.toUpperCase());

		byte[] data2 = new byte[] { (byte) 0xFF, 0x01, 0x22, 0x03, 0x44, 0x05, 0x66, 0x07, (byte) 0x88, (byte) 0x09,
				(byte) 0xaa, (byte) 0x0b };

		er = Jreader.WriteTagEpcEx(1, data2, 12, null, (short) 1000);
		System.out.println("write2:" + er.toString());
		er = Jreader.GetTagData(1, (char) 1, 2, 6, datar, null, (short) 1000);

		str1 = "";

		if (er == READER_ERR.MT_OK_ERR)
			str1 = Jreader.bytes_Hexstr(datar);
		System.out.println(er.toString() + " " + str1.toUpperCase());

	}

	/**
	 * ����������
	 */
	public void testblockop() {
		String pwd = "11000000";
		byte[] data = new byte[4];
		Jreader.Str2Hex(pwd, pwd.length(), data);
		// ������
		READER_ERR er = Jreader.BlockErase(1, (char) 1, 2, 12, data, (short) 1000);

		// ��������
		Jreader.BlockPermaLock(1, 1, 2, 6, new byte[] { (byte) 0xff, (byte) 0xff }, data, (short) 1000);

	}

	public boolean testinitreader() {
		// ������д��
		/*
		 * �������߿����Ӷ�д�� src �ǵ�ַ ip��ַ���ߴ��ں� rtype �����߿�����4�����ߴ���4 �������ͣ�READER_ERR
		 * ,MT_OK_ERR��ʾ������������ʾ����
		 */
		// READER_ERR
		// er=Jreader.InitReader("com3",Reader_Type.MODULE_FOUR_ANTS);
		READER_ERR er = Jreader.InitReader_Notype(ReaderAddr, AntCount);
		JOptionPane.showMessageDialog(null, "����:" + ReaderAddr + " c:" + AntCount + " re:" + er.toString(), "��Ϣ��ʾ",
				JOptionPane.INFORMATION_MESSAGE);
		System.out.println(er.toString());
		
		HardwareDetails val = Jreader.new HardwareDetails();
		er = Jreader.GetHardwareDetails(val);
		 
		ReaderVersion rdrver = Jreader.new ReaderVersion();
		Jreader.ParamGet(Mtr_Param.MTR_PARAM_READER_VERSION, rdrver);

		System.out.println("module:" + val.module.toString() + "\r\nsoftwareVer:" +
				rdrver.softwareVer + "\r\nhardwareVer:" + rdrver.hardwareVer);

		if (er != READER_ERR.MT_OK_ERR)
			return false;
		int[] val2 = new int[1];
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_READER_AVAILABLE_ANTPORTS, val2);
		/*
		 * ���������鹦�ʣ�AntPowerConf ��Ա�� AntPower���� antcnt��ʾ���߸��� AntPower���� antid ���ߺ�
		 * readPower ������ writePower д����
		 */

		AntPowerConf apcf = Jreader.new AntPowerConf();
		apcf.antcnt = AntCount;
		for (int i = 0; i < apcf.antcnt; i++) {
			AntPower jaap = Jreader.new AntPower();
			jaap.antid = i + 1;
			jaap.readPower = 3000;
			jaap.writePower = 3000;
			apcf.Powers[i] = jaap;
		}
		AntPowerConf apcf2 = Jreader.new AntPowerConf();
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_RF_ANTPOWER, apcf);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_RF_ANTPOWER, apcf2);
		for (int i = 0; i < apcf2.antcnt; i++) {
			System.out.print("antid:" + apcf2.Powers[i].antid);
			System.out.print(" rp:" + apcf2.Powers[i].readPower);
			System.out.print(" wp:" + apcf2.Powers[i].writePower);
			System.out.println();
		}

		Inv_Potls_ST ipst = Jreader.new Inv_Potls_ST();
		ipst.potlcnt = 1;
		ipst.potls = new Inv_Potl[1];
		for (int i = 0; i < ipst.potlcnt; i++) {
			Inv_Potl ipl = Jreader.new Inv_Potl();
			ipl.weight = 30;
			ipl.potl = SL_TagProtocol.SL_TAG_PROTOCOL_GEN2;
			ipst.potls[0] = ipl;
		}

		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_INVPOTL, ipst);

		/*
		 * �����Ƿ������� ������ֵ����1��ʱ���ʾҪ��飬0��ʾ�����
		 */
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_READER_IS_CHK_ANT, new int[] { 0 });
		return true;
	}

    //�Ѳ��õĽӿ�
	public void testinventory1() {
		/*
		 * 
		 * ����Ƶ�ʣ�����ĳ��������Ƶ�ʱ���������Ч�� HoptableData_ST ����Ƶ�ʱ��� lenhtb ��ʾƵ�ʱ����� htb
		 * ����int���ͣ���ʾ����Ƶ�� HoptableData_ST hdst=Jreader.new HoptableData_ST();
		 * hdst.lenhtb=2; hdst.htb[0]=915250; hdst.htb[1]=915750;
		 * 
		 * READER_ERR
		 * er=Jreader.ParamSet(Mtr_Param.MTR_PARAM_FREQUENCY_HOPTABLE,hdst);
		 */

		/*
		 * ants ��ѯʹ�õ����ߣ����������߿ڵ����� antcnt ʹ�õ����߸��� timeout ����ǩ��ʱ�� pTInfo ��ű�ǩ���ݵ�����
		 * tagcnt ��ű�ǩ�ĸ�����ֻ�贫��һ��Ԫ�ص�����
		 */
		int[] tagcnt = new int[1];
		TAGINFO[] taginfo = new TAGINFO[200];
		READER_ERR er = Jreader.TagInventory(new int[] { 1 }, 1, (short) 1000, taginfo, tagcnt);

		if (er == READER_ERR.MT_OK_ERR) {

			for (int i = 0; i < tagcnt[0]; i++) {

				System.out.println("inv1_epc:" + Reader.bytes_Hexstr(taginfo[i].EpcId));
			}
		}
	}

	/**
	 * ��ͨģʽ�̵�/ͬ��ģʽ�̵�
	 */
	public void testinventory2() {
		int[] tagcnt = new int[1];
		TAGINFO taginfo = Jreader.new TAGINFO();
		READER_ERR er = Jreader.TagInventory_Raw(new int[] { 1 }, 1, (short) 1000, tagcnt);
		for (int i = 0; i < tagcnt[0]; i++) {
			er = Jreader.GetNextTag(taginfo);
			if (taginfo != null)
				System.out.println("inv2_epc:" + Reader.bytes_Hexstr(taginfo.EpcId));
		}

		byte[] outbuf = new byte[800];

		//������ǩ����Ϊ�������ͣ��ֽ����飩
		er = Jreader.TagInventory_Raw(new int[] { 1 }, 1, (short) 1000, tagcnt);
		er = Jreader.GetNextTag_BaseType(outbuf);

	}

	/*
	 * ͬ���̵㲢��10����ȥ�ع���
	 */
	public void testinventory3() {
		for (int t = 0; t < 50; t++) {
			int[] tagcnt = new int[1];
			TAGINFO taginfo = Jreader.new TAGINFO();
			READER_ERR er = Jreader.TagInventory_Raw(new int[] { 1 }, 1, (short) 1000, tagcnt);
			if (er == READER_ERR.MT_OK_ERR) {
				for (int i = 0; i < tagcnt[0]; i++) {
					er = Jreader.GetNextTag(taginfo);
					String tagepc = Reader.bytes_Hexstr(taginfo.EpcId);
					if (taginfo != null)
						System.out.println("inv2_epc:" + tagepc);

					// �ж��Ƿ������ǩ
					if (TagsMap.containsKey(tagepc)) {
						// ������ǩ�ж��Ƿ���ʮ��֮��
						Tagandtime tat = TagsMap.get(tagepc);
						if (System.currentTimeMillis() - tat.time >= 10 * 1000) {
							// ʮ��֮��ı�ǩ�����ô�����ǩ�¼�
							tat.time = System.currentTimeMillis();
							System.out.println(
									"tag event: over ten senconds +++" + String.valueOf(TagsMap.get(tagepc).time));
						} else {
							// ʮ��֮�ڵı�ǩ�������κδ���
							System.out.println("no tag event ===");
						}
					} else {
						Tagandtime tat = new Tagandtime();
						tat.taginfo = taginfo;
						tat.time = System.currentTimeMillis();
						TagsMap.put(Reader.bytes_Hexstr(taginfo.EpcId), tat);
						// ��������ǩ��������ǩ�¼�
						System.out.println("tag event new tag +++" + String.valueOf(TagsMap.get(tagepc).time));
					}
				}
			}
		}
	}

	/**
	 * ͬ���̵㲢�Ҵ��������� tid bank 4 �����ݣ�8�ֽڣ�
	 */
	public void testinventory3_emddata() {
		EmbededData_ST edst = Jreader.new EmbededData_ST();
		edst.startaddr = 0;
		edst.bank = 2;
		// bytecnt=0 ����ȡ��Ƕ������
		edst.bytecnt = 8;
		edst.accesspwd = null;
		Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_EMBEDEDDATA, edst);
		// Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_EMBEDEDDATA, null);//ȡ��Ƕ������

		int[] tagcnt = new int[1];
		TAGINFO taginfo = Jreader.new TAGINFO();
		READER_ERR er = Jreader.TagInventory_Raw(new int[] { 1 }, 1, (short) 1000, tagcnt);
		if (er == READER_ERR.MT_OK_ERR && tagcnt[0] > 0) {
			for (int i = 0; i < tagcnt[0]; i++) {
				er = Jreader.GetNextTag(taginfo);
				if (taginfo != null)
					System.out.println("inv3_epc:" + Reader.bytes_Hexstr(taginfo.EpcId) + " tid:"
							+ Reader.bytes_Hexstr(taginfo.EmbededData));
			}
		}
	}

	/*
	 * �첽�̵㣨����ģʽ��
	 */
	private Reader.READER_ERR startReadTags() {

		int antcnt = 2;
		int[] ants = new int[antcnt];
		ants[0] = 1;
		ants[1] = 3;
		Reader.READER_ERR readerErr = Jreader.AsyncStartReading(ants, antcnt, 0x0004 << 8);
		if (readerErr != Reader.READER_ERR.MT_OK_ERR) {
			ErrInfo eif = new ErrInfo();
			Jreader.GetLastDetailError(eif);
			JOptionPane.showMessageDialog(null, "errcode:" + eif.derrcode + eif.errstr, "������ʾ",
					JOptionPane.INFORMATION_MESSAGE);
		}
		return readerErr;
	}

	/**
	 * ����arm7 ��д���洢����������
	 */
	public void testdataonreader() {
		byte[] data3 = new byte[100];
		READER_ERR er = Jreader.ReadDataOnReader(0, data3, 100);
		er = Jreader.SaveDataOnReader(0, data3, 100);

		// ������д��������
		er = Jreader.EraseDataOnReader();
	}

	/**
	 * �������ٱ�ǩ,���Ȱ���������д������������
	 */
	public void testkilltag() {
		String pwd = "11000000";
		byte[] data = new byte[4];
		Jreader.Str2Hex(pwd, pwd.length(), data);
		READER_ERR er = Jreader.KillTag(1, data, (short) 1000);
	}

	/**
	 * ����������ǩ�����Ȱѷ�������д�����������
	 */
	public void testlocktag() {
		String pwd = "12340000";
		// READER_ERR er=Jreader.Lock180006BTag(1, 2, 6, (short) 1000);
		byte[] data = new byte[4];
		Jreader.Str2Hex(pwd, pwd.length(), data);

		// д����
		READER_ERR er = Jreader.WriteTagData(1, (char) 0, 2, data, 2, null, (short) 1000);
		er = Jreader.LockTag(1, (byte) Lock_Obj.LOCK_OBJECT_BANK1.value(), (short) Lock_Type.BANK1_LOCK.value(), data,
				(short) 1000);

		// д����
		er = Jreader.WriteTagData(1, (char) 1, 2, new byte[] { 0x11, 0x22 }, 2, null, (short) 1000);
		System.out.println("no pwd write" + er.toString());

		// д����
		er = Jreader.WriteTagData(1, (char) 1, 2, new byte[] { 0x11, 0x22 }, 2, data, (short) 1000);
		System.out.println("pwd write" + er.toString());

		er = Jreader.LockTag(1, (byte) Lock_Obj.LOCK_OBJECT_BANK1.value(), (short) Lock_Type.BANK1_UNLOCK.value(), data,
				(short) 1000);
	}

	/**
	 * �������ö�д��IP
	 */
	public void testsetip() {
		Reader_Ip rip = Jreader.new Reader_Ip();
		/*
		 * rip.ip=new
		 * byte[]{'1','9','2','.','1','6','8','.','1','.','1','0','1'};
		 * rip.mask=new
		 * byte[]{'2','5','5','.','2','5','5','.','2','5','5','.','0'};
		 * rip.gateway=new
		 * byte[]{'1','9','2','.','1','6','8','.','1','.','2','5','4'}; //
		 */

		rip.ip = "192.168.1.101".getBytes();
		rip.mask = "255.255.255.0".getBytes();
		rip.gateway = "192.168.1.1".getBytes();
		// */

		READER_ERR er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_READER_IP, rip);

	}

	/**
	 * �������ò���
	 */
	public void testrparams() {
		
		int[] valso2 = new int[1];
		valso2[0]=0;
		 Jreader.ParamGet(Mtr_Param.MTR_PARAM_RF_MAXPOWER, valso2);
		System.out.println("max:" + valso2[0]);

		// er=Jreader.ParamSet(Mtr_Param.MTR_PARAM_RF_MINPOWER, val1);
		 Jreader.ParamGet(Mtr_Param.MTR_PARAM_RF_MINPOWER, valso2);
		System.out.println("min:" + valso2[0]);
		
		
		HoptableData_ST hdst = Jreader.new HoptableData_ST();
		hdst.lenhtb = 5;
		hdst.htb[0] = 915250;
		hdst.htb[1] = 916750;
		hdst.htb[2] = 917250;
		hdst.htb[3] = 925750;
		hdst.htb[4] = 926750;
		READER_ERR er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_FREQUENCY_HOPTABLE, hdst);

		HoptableData_ST hdst2 = Jreader.new HoptableData_ST();
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_FREQUENCY_HOPTABLE, hdst2);
		for (int i = 0; i < hdst2.lenhtb; i++) {
			System.out.print("htb:" + i);
			System.out.println(" " + (hdst2.htb[i]));
		}

		//
		Region_Conf rcf1 = Region_Conf.RG_NA;
		Region_Conf[] rcf2 = new Region_Conf[1];

		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_FREQUENCY_REGION, rcf1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_FREQUENCY_REGION, rcf2);

		int[] val1 = new int[] { 250 };
		int[] val2 = new int[] { -1 };
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_POTL_GEN2_BLF, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_POTL_GEN2_BLF, val2);

		val1[0] = 496;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_POTL_GEN2_MAXEPCLEN, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_POTL_GEN2_MAXEPCLEN, val2);

		val1[0] = 10;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_POTL_GEN2_Q, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_POTL_GEN2_Q, val2);

		val1[0] = 2;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_POTL_GEN2_SESSION, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_POTL_GEN2_SESSION, val2);

		val1[0] = 2;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_POTL_GEN2_TAGENCODING, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_POTL_GEN2_TAGENCODING, val2);

		val1[0] = 1;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_POTL_GEN2_TARGET, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_POTL_GEN2_TARGET, val2);

		val1[0] = 3;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_POTL_GEN2_TARI, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_POTL_GEN2_TARI, val2);

		val1[0] = 1;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_POTL_GEN2_WRITEMODE, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_POTL_GEN2_WRITEMODE, val2);

		val1[0] = 40;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_POTL_ISO180006B_BLF, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_POTL_ISO180006B_BLF, val2);

		val1[0] = 1;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_POTL_ISO180006B_DELIMITER, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_POTL_ISO180006B_DELIMITER, val2);

		val1[0] = 2;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_POTL_ISO180006B_MODULATION_DEPTH, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_POTL_ISO180006B_MODULATION_DEPTH, val2);

		// er=Jreader.ParamSet(Mtr_Param.MTR_PARAM_POTL_SUPPORTEDPROTOCOLS,
		// val1);
		// er=Jreader.ParamGet(Mtr_Param.MTR_PARAM_POTL_SUPPORTEDPROTOCOLS,
		// val2);

		val1[0] = 1;
		val2[0] = -1;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_POWERSAVE_MODE, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_POWERSAVE_MODE, val2);

		// er=Jreader.ParamSet(Mtr_Param.MTR_PARAM_READER_AVAILABLE_ANTPORTS,
		// val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_READER_AVAILABLE_ANTPORTS, val2);

		ConnAnts_ST cast = Jreader.new ConnAnts_ST();
		// er=Jreader.ParamSet(Mtr_Param.MTR_PARAM_READER_CONN_ANTS, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_READER_CONN_ANTS, cast);

		Reader_Ip rip2 = Jreader.new Reader_Ip();
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_READER_IP, rip2);
		System.out.print("ip:" + rip2.ip.length + " ");
		System.out.println(new String(rip2.ip));
		System.out.println(new String(rip2.mask));
		System.out.println(new String(rip2.gateway));

		val1[0] = 1;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_READER_IS_CHK_ANT, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_READER_IS_CHK_ANT, val2);

		// er=Jreader.ParamSet(Mtr_Param.MTR_PARAM_READER_VERSION, val1);
		// er=Jreader.ParamGet(Mtr_Param.MTR_PARAM_READER_VERSION, val2);

		AntPowerConf apcf = Jreader.new AntPowerConf();
		apcf.antcnt = 1;
		for (int i = 0; i < apcf.antcnt; i++) {
			AntPower jaap = Jreader.new AntPower();
			jaap.antid = i + 1;
			jaap.readPower = 2800;
			jaap.writePower = 2750;
			apcf.Powers[i] = jaap;
		}
		AntPowerConf apcf2 = Jreader.new AntPowerConf();
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_RF_ANTPOWER, apcf);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_RF_ANTPOWER, apcf2);
		for (int i = 0; i < apcf2.antcnt; i++) {
			System.out.print("antid:" + apcf2.Powers[i].antid);
			System.out.print(" rp:" + apcf2.Powers[i].readPower);
			System.out.print(" wp:" + apcf2.Powers[i].writePower);
			System.out.println();
		}

		val1[0] = 100;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_RF_HOPTIME, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_RF_HOPTIME, val2);

		val1[0] = 1;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_RF_LBT_ENABLE, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_RF_LBT_ENABLE, val2);

		// er=Jreader.ParamSet(Mtr_Param.MTR_PARAM_RF_MAXPOWER, val1);
		int[] valso = new int[1];
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_RF_MAXPOWER, valso);
		System.out.println("max:" + valso[0]);

		// er=Jreader.ParamSet(Mtr_Param.MTR_PARAM_RF_MINPOWER, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_RF_MINPOWER, valso);
		System.out.println("min:" + valso[0]);
		// er=Jreader.ParamSet(Mtr_Param.MTR_PARAM_RF_SUPPORTEDREGIONS, val1);
		// er=Jreader.ParamGet(Mtr_Param.MTR_PARAM_RF_SUPPORTEDREGIONS, val2);

		// er=Jreader.ParamSet(Mtr_Param.MTR_PARAM_RF_TEMPERATURE, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_RF_TEMPERATURE, val2);

		EmbededData_ST edst = Jreader.new EmbededData_ST();
		edst.startaddr = 0;
		edst.bank = 2;
		// bytecnt=0 ȡ��Ƕ������
		edst.bytecnt = 2;
		edst.accesspwd = null;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_EMBEDEDDATA, edst);

		EmbededData_ST edst2 = Jreader.new EmbededData_ST();
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_TAG_EMBEDEDDATA, edst2);

		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_EMBEDEDDATA, null);

		EmbededSecureRead_ST esrst = Jreader.new EmbededSecureRead_ST();
		esrst.accesspwd = 1280;
		esrst.address = 2;
		esrst.ApIndexBitsNumInEpc = 1;
		esrst.ApIndexStartBitsInEpc = 3;
		esrst.bank = 1;
		// blkcnt =0 ȡ����
		esrst.blkcnt = 2;
		esrst.pwdtype = 1;
		esrst.tagtype = 2;
		EmbededSecureRead_ST esrst2 = Jreader.new EmbededSecureRead_ST();
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_EMDSECUREREAD, esrst);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_TAG_EMDSECUREREAD, esrst2);
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_EMDSECUREREAD, null);

		TagFilter_ST tfst = Jreader.new TagFilter_ST();
		tfst.bank = 1;
		tfst.fdata = new byte[] { (byte) 0xE2, (byte) 0x00 };

		tfst.flen = 16;
		tfst.isInvert = 0;
		tfst.startaddr = 32;
		TagFilter_ST tfst2 = Jreader.new TagFilter_ST();

		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_FILTER, tfst);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_TAG_FILTER, tfst2);
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_FILTER, null);

		Inv_Potls_ST ipst = Jreader.new Inv_Potls_ST();
		ipst.potlcnt = 1;
		ipst.potls = new Inv_Potl[1];
		for (int i = 0; i < ipst.potlcnt; i++) {
			Inv_Potl ipl = Jreader.new Inv_Potl();
			ipl.weight = 30;
			ipl.potl = SL_TagProtocol.SL_TAG_PROTOCOL_GEN2;
			ipst.potls[0] = ipl;
		}

		Inv_Potls_ST ipst2 = Jreader.new Inv_Potls_ST();
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_INVPOTL, ipst);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_TAG_INVPOTL, ipst2);
		for (int i = 0; i < ipst2.potlcnt; i++)
			System.out.println(ipst2.potls[i].potl);

		val1[0] = 1;
		val2[0] = 0;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_SEARCH_MODE, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_TAG_SEARCH_MODE, val2);

		val1[0] = 1;
		val2[0] = 0;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAGDATA_RECORDHIGHESTRSSI, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_TAGDATA_RECORDHIGHESTRSSI, val2);

		val1[0] = 1;
		val2[0] = 0;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAGDATA_UNIQUEBYANT, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_TAGDATA_UNIQUEBYANT, val2);

		val1[0] = 1;
		val2[0] = 0;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAGDATA_UNIQUEBYEMDDATA, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_TAGDATA_UNIQUEBYEMDDATA, val2);

		val1[0] = 300;
		val2[0] = 0;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TRANS_TIMEOUT, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_TRANS_TIMEOUT, val2);

		val1[0] = 1;
		val2[0] = 0;
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TRANSMIT_MODE, val1);
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_TRANSMIT_MODE, val2);
	}

	// �����ھ����ǩ����ǰ����Ƿ�ֻ��һ����ǩ�����߳���,�������Ա�ǩ��EPC��
	// Ϊ�������������Ժ�ı�ǩ����
	boolean PreTagOp(String uii) {
		int[] tagcnt = new int[1];
		TAGINFO taginfo = Jreader.new TAGINFO();

		// ������� �̵�
		Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_FILTER, null);

		// ����1200 �������ݣ�����tid
		EmbededData_ST edst = Jreader.new EmbededData_ST();
		edst.startaddr = 0;
		edst.bank = 2;
		// bytecnt=0 ȡ��Ƕ������
		edst.bytecnt = 12;
		edst.accesspwd = null;

		READER_ERR err = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_EMBEDEDDATA, edst);

		err = Jreader.TagInventory_Raw(new int[] { 1 }, 1, (short) 300, tagcnt);
		if (err != READER_ERR.MT_OK_ERR) {
			System.out.println("�̴�ʧ��,������:" + err.toString());
			return false;
		}
		if (tagcnt[0] != 1) {
			System.out.println("��ȷ�����߳�������ֻ��һ����ǩ");
			return false;
		}
		// ��ȡ��ǰ���߳��ڴ��ڵ�Ψһ��ǩ��EPC��
		err = Jreader.GetNextTag(taginfo);
		if (err != READER_ERR.MT_OK_ERR) {
			System.out.println("��ȡ��ǩʧ��,������:" + err.toString());
			return false;
		}

		// ��û�ж���tid������false��
		if (taginfo.EmbededDatalen < 1)
			return false;

		char[] out = new char[taginfo.EmbededDatalen * 2];
		Jreader.Hex2Str(taginfo.EmbededData, taginfo.EmbededDatalen, out);

		// ����ָ����uii
		if (!uii.equals(String.valueOf(out)))
			return false;

		// �����Ա�ǩ��TID��Ϊ�������������Ժ�ı�ǩ����
		TagFilter_ST tfst = Jreader.new TagFilter_ST();
		tfst.bank = 2;
		tfst.fdata = taginfo.EmbededData;
		tfst.flen = taginfo.EmbededDatalen * 8;
		tfst.isInvert = 0;
		tfst.startaddr = 0;

		err = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_FILTER, tfst);
		return true;
	}

	// ͨ��epcid ��tid
	boolean PreTagOp2(String uii) {
		int[] tagcnt = new int[1];
		TAGINFO taginfo = Jreader.new TAGINFO();

		// ������� �̵�
		Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_FILTER, null);

		READER_ERR err = Jreader.TagInventory_Raw(new int[] { 1 }, 1, (short) 300, tagcnt);
		if (err != READER_ERR.MT_OK_ERR) {
			System.out.println("�̴�ʧ��,������:" + err.toString());
			return false;
		}
		if (tagcnt[0] != 1) {
			System.out.println("��ȷ�����߳�������ֻ��һ����ǩ");
			return false;
		}
		// ��ȡ��ǰ���߳��ڴ��ڵ�Ψһ��ǩ��EPC��
		err = Jreader.GetNextTag(taginfo);
		if (err != READER_ERR.MT_OK_ERR) {
			System.out.println("��ȡ��ǩʧ��,������:" + err.toString());
			return false;
		}

		// �����Ա�ǩ��EPC��Ϊ�������������Ժ�ı�ǩ����
		TagFilter_ST tfst = Jreader.new TagFilter_ST();
		tfst.bank = 1;
		tfst.fdata = taginfo.EpcId;
		tfst.flen = taginfo.Epclen * 8;
		tfst.isInvert = 0;
		tfst.startaddr = 32;

		err = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_FILTER, tfst);
		byte[] datab = new byte[12];
		err = Jreader.GetTagData(1, (char) 2, 0, 6, datab, null, (short) 1000);
		String tidstr = "";
		if (err == READER_ERR.MT_OK_ERR)
			tidstr = Jreader.bytes_Hexstr(datab);
		else
			return false;

		// ����ָ����uii
		if (!uii.equals(String.valueOf(tidstr)))
			return false;

		// �����Ա�ǩ��TID��Ϊ�������������Ժ�ı�ǩ����
		TagFilter_ST tfst2 = Jreader.new TagFilter_ST();
		tfst2.bank = 2;
		tfst2.fdata = datab;
		tfst2.flen = datab.length * 8;
		tfst2.isInvert = 0;
		tfst2.startaddr = 0;

		err = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_FILTER, tfst2);
		return true;
	}

	/**
	 * 
	 * @param accessPwd ��������
	 * @param bank ����
	 * @param ptr ��ʼλ��
	 * @param cnt ����
	 * @param data ��д�������
	 * @param uii ԭʼ��
	 * @return
	 */
	public boolean writeData(String accessPwd, int bank, int ptr, int cnt, String data, String uii) {
		if (!PreTagOp(uii))
			return false;
		byte[] accesspwdb = new byte[4];
		Jreader.Str2Hex(accessPwd, accessPwd.length(), accesspwdb);
		byte[] datab = new byte[data.length() / 2];
		Jreader.Str2Hex(data, data.length(), datab);
		int opant = 1;// ָ������1����
		READER_ERR er = Jreader.WriteTagData(opant, (char) bank, ptr, datab, datab.length, accesspwdb, (short) 1000);

		if (er == READER_ERR.MT_OK_ERR)
			return true;
		else
			return false;
	}

	/**
	 * ����gpio
	 */
	public void testgpio() {
		READER_ERR er = Jreader.SetGPO(1, 1);
		er = Jreader.SetGPO(2, 0);
		er = Jreader.SetGPO(3, 0);
		er = Jreader.SetGPO(4, 1);
		er = Jreader.SetGPO(4, 0);
		int[] val = new int[1];
		er = Jreader.GetGPI(1, val);
		er = Jreader.GetGPI(2, val);
		er = Jreader.GetGPI(3, val);
		er = Jreader.GetGPI(4, val);
	}

	/**
	 * ����Ĭ�ϲ�����
	 */
	public void testdefaultbaudrate() {
		Default_Param dp = Jreader.new Default_Param();
		dp.isdefault = false;
		dp.key = Mtr_Param.MTR_PARAM_SAVEINMODULE_BAUD;
		dp.val = 57600;
		Jreader.ParamSet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp);
	}

	
	/**
	 * ���Ի�ȡ������Ϣ
	 * @param er
	 */
	public void testerrinfo(READER_ERR er) {
		if (er != READER_ERR.MT_OK_ERR)
		{	ErrInfo ei = new ErrInfo();
			Jreader.GetLastDetailError(ei);
			 
			System.out.println("last errcode:" + Integer.toHexString(ei.derrcode) +"  errstr:"+ ei.errstr);
		}
	}

	
	/**
	 * ���Ի�ȡmac
	 */
	public void testgetmac() {
		Reader.CustomParam_ST cpara = Jreader.new CustomParam_ST();
		cpara.ParamName = "reader/macaddr";
		READER_ERR ret = Jreader.ParamGet(Reader.Mtr_Param.MTR_PARAM_CUSTOM, cpara);
		System.out.println(cpara.ParamVal[0]);
		// cpara.ParamVal ����mac��ַ
	}
	
	/**
	 * �������û�ȡ�ϵ�Ĭ��ֵ
	 */
	public void testdefaultvalue()
	{
		Default_Param dp=Jreader.new Default_Param();
		dp.key=Mtr_Param.MTR_PARAM_RF_ANTPOWER;
		dp.isdefault=true;
		AntPowerConf apcf = Jreader.new AntPowerConf();
		//apcf.antcnt = AntCount;
		apcf.antcnt = 4;
		int st=1;
		for (int i = 0; i < apcf.antcnt; i++) {
			AntPower jaap = Jreader.new AntPower();
			//jaap.antid = i + 1;
			jaap.antid = i + st;
			jaap.readPower = (short) (2400+jaap.antid*10);
			jaap.writePower = (short) (2400+jaap.antid*10);
			apcf.Powers[i] = jaap;
		}
		dp.val=apcf;
		
		Default_Param dp2=Jreader.new Default_Param();
		dp2.key=Mtr_Param.MTR_PARAM_RF_ANTPOWER;
		
		
		@SuppressWarnings("unused")
		READER_ERR ret =Jreader.ParamSet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp);
		ret =Jreader.ParamGet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp2);
		 
		dp.isdefault=false;
		ret =Jreader.ParamSet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp);
		ret =Jreader.ParamGet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp2);
		
		
		
		dp=Jreader.new Default_Param();
		dp.key=Mtr_Param.MTR_PARAM_POTL_GEN2_Q;
		//dp.isdefault=true;  ע������Ĭ��ֵͬʱӰ�� Q��TARGET��Session
		dp.val=1;
		//ret =Jreader.ParamSet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp);
		
		dp2=Jreader.new Default_Param();
		dp2.key=Mtr_Param.MTR_PARAM_POTL_GEN2_Q;
		//ret =Jreader.ParamGet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp2);
		
		dp.isdefault=false;
		ret =Jreader.ParamSet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp);
		ret =Jreader.ParamGet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp2);
		
		
		dp=Jreader.new Default_Param();
		dp.key=Mtr_Param.MTR_PARAM_POTL_GEN2_SESSION;
		//dp.isdefault=true; ע������Ĭ��ֵͬʱӰ�� Q��TARGET��Session
		dp.val=1;
		//ret =Jreader.ParamSet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp);
		
		dp2=Jreader.new Default_Param();
		dp2.key=Mtr_Param.MTR_PARAM_POTL_GEN2_SESSION;
		//ret =Jreader.ParamGet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp2);
		
		dp.isdefault=false;
		ret =Jreader.ParamSet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp);
		ret =Jreader.ParamGet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp2);
		
		
		dp=Jreader.new Default_Param();
		dp.key=Mtr_Param.MTR_PARAM_POTL_GEN2_TARGET;
		//dp.isdefault=true;ע������Ĭ��ֵͬʱӰ�� Q��TARGET��Session
		dp.val=1;
		//ret =Jreader.ParamSet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp);
		
		dp2=Jreader.new Default_Param();
		dp2.key=Mtr_Param.MTR_PARAM_POTL_GEN2_TARGET;
		//ret =Jreader.ParamGet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp2);
		
		dp.isdefault=false;
		ret =Jreader.ParamSet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp);
		ret =Jreader.ParamGet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp2);
		
		
		dp=Jreader.new Default_Param();
		dp.key=Mtr_Param.MTR_PARAM_FREQUENCY_REGION;
		dp.isdefault=true;
		dp.val=Region_Conf.RG_PRC;
		ret =Jreader.ParamSet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp);
		
		dp2=Jreader.new Default_Param();
		dp2.key=Mtr_Param.MTR_PARAM_FREQUENCY_REGION;
		ret =Jreader.ParamGet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp2);
		
		dp.isdefault=false;
		ret =Jreader.ParamSet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp);
		ret =Jreader.ParamGet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp2);
		
		
		
		dp=Jreader.new Default_Param();
		dp.subkey="modulesave/antport";
		dp.key=Mtr_Param.MTR_PARAM_SAVEINMODULE;
		dp.isdefault=false;
		dp.val=new Integer[]{1,2,3};
		ret =Jreader.ParamSet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp);
		
		dp2=Jreader.new Default_Param();
		dp2.key=Mtr_Param.MTR_PARAM_SAVEINMODULE;
		dp2.subkey="modulesave/antport";
		ret =Jreader.ParamGet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp2);
		
		//dp.isdefault=true;
		//ret =Jreader.ParamSet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp);
		//ret =Jreader.ParamGet(Mtr_Param.MTR_PARAM_SAVEINMODULE, dp2);
		
	}

	READER_ERR FlushDummyData2Mod() {
		/* if (m_stream->isOpen) */
		{
			byte[] zerobuf = new byte[255];
			zerobuf[0] = (byte) 0xff;
			zerobuf[1] = (byte) 250;
			zerobuf[2] = 0x0;
			for (int i = 3; i < 255; ++i)
				zerobuf[i] = 0;

			Jreader.DataTransportSend(zerobuf, 255, 2000);

			return READER_ERR.MT_OK_ERR;
		}

	}

	READER_ERR TestModLive() {

		READER_ERR err = READER_ERR.MT_OK_ERR;
		byte[] cmd = new byte[] { (byte) 0xff, 0x00, 0x03, 0x1d, 0x0c };
		byte[] resp = new byte[50];
		byte[] resp2 = new byte[50];
		Jreader.DataTransportSend(cmd, cmd.length, 1000);
		if (Jreader.DataTransportRecv(resp, 5, 1000) == -1)
			return READER_ERR.MT_CMD_FAILED_ERR;
		if (Jreader.DataTransportRecv(resp2, resp[1] + 2, 1000) == -1)
			return READER_ERR.MT_CMD_FAILED_ERR;
		return err;

	}

	class MsgObj {
		public byte[] soh = new byte[1];
		public byte[] dataLen = new byte[1];
		public byte[] opCode = new byte[1];
		public byte[] status = new byte[2];
		public byte[] crc = new byte[2];
		public byte[] data = new byte[250];

		public byte[] getcheckcrcdata() {
			byte[] crcb = new byte[dataLen[0] + 4];
			int p = 0;
			crcb[p] = dataLen[0];
			p++;
			crcb[p++] = opCode[0];
			crcb[p++] = status[0];
			crcb[p++] = status[1];
			for (int i = 0; i < dataLen[0]; i++)
				crcb[p++] = data[i];
			return crcb;
		}
	}

	private int SendandRev(byte[] data, int timeout, MsgObj hMsg) {
		int COMM_NON_FATAL_ERR = 0xfefd;
		int MODULE_NEED_RESTART = 0xfefe;
		short MSG_CRC_INIT = (short) 0xFFFF;

		System.out.println("send:" + Jreader.bytes_Hexstr(data));

		int re = Jreader.DataTransportSend(data, data.length, timeout);
		if (re != 0)
			return COMM_NON_FATAL_ERR;

		short scrc;
		READER_ERR err = READER_ERR.MT_OK_ERR;
		int ret = 0;

		System.out.print("revd:");
		ret = Jreader.DataTransportRecv(hMsg.soh, 1, 1000);
		System.out.print(Jreader.bytes_Hexstr(hMsg.soh));

		if (ret == -2 || ret == -3)
			return COMM_NON_FATAL_ERR;
		else if (ret == -1)
			return READER_ERR.MT_IO_ERR.value();
		else if (ret == -4) {
			// ����ģ�鴦�ڵȴ�ָ��״̬
			if (FlushDummyData2Mod() != READER_ERR.MT_OK_ERR) {
				return READER_ERR.MT_IO_ERR.value();
			}
			if (TestModLive() == READER_ERR.MT_OK_ERR) {
				return COMM_NON_FATAL_ERR;
			} else {
				return MODULE_NEED_RESTART;
			}
		}

		if ((hMsg.soh[0] & 0xff) != 0xff) {
			if (FlushDummyData2Mod() != READER_ERR.MT_OK_ERR) {
				return READER_ERR.MT_IO_ERR.value();
			} else {
				return 0xfefd;
			}
		}

		scrc = MSG_CRC_INIT;

		if (Jreader.DataTransportRecv(hMsg.dataLen, 1, 1000) == -1) {
			return COMM_NON_FATAL_ERR;
		}
		System.out.print(Jreader.bytes_Hexstr(hMsg.dataLen));

		if (Jreader.DataTransportRecv(hMsg.opCode, 1, 1000) == -1) {
			return COMM_NON_FATAL_ERR;
		}
		System.out.print(Jreader.bytes_Hexstr(hMsg.opCode));

		if (Jreader.DataTransportRecv(hMsg.status, 2, 1000) == -1) {
			return COMM_NON_FATAL_ERR;
		}
		System.out.print(Jreader.bytes_Hexstr(hMsg.status));

		if (hMsg.dataLen[0] > 0) {
			if (Jreader.DataTransportRecv(data, hMsg.dataLen[0], 1000) == -1) {
				return COMM_NON_FATAL_ERR;
			}
			byte[] fdata = new byte[hMsg.dataLen[0]];
			System.arraycopy(data, 0, fdata, 0, hMsg.dataLen[0]);
			System.out.print(Jreader.bytes_Hexstr(fdata));
		}

		if (Jreader.DataTransportRecv(hMsg.crc, 2, 1000) == -1) {
			return COMM_NON_FATAL_ERR;
		}
		System.out.println(Jreader.bytes_Hexstr(hMsg.crc));

		scrc = (short) (((hMsg.crc[0] & 0xFF) << 8) | (hMsg.crc[1] & 0xFF));

		if (R2000_calibration.calcCrc_short(hMsg.getcheckcrcdata()) != scrc) {
			/* SLOS_Sleep(1500); */
			if (FlushDummyData2Mod() != READER_ERR.MT_OK_ERR) {
				return READER_ERR.MT_IO_ERR.value();
			} else {
				return COMM_NON_FATAL_ERR;
			}
		}

		if (err != READER_ERR.MT_OK_ERR) {
			if (FlushDummyData2Mod() != READER_ERR.MT_OK_ERR)
				return READER_ERR.MT_IO_ERR.value();
		}
		return err.value();

	}

	/**
	 *�����ز�����
	 */
	public void testcarrywave() {
		// ant power
		R2000_calibration r2000pcmd = new R2000_calibration();
		int ant = 1, power = 2000;
		R2000_calibration.ENGTest_DATA et = r2000pcmd.new ENGTest_DATA(
				(byte) R2000_calibration.SubCmd.SetTestAntPow.Value(), ant, power);
		byte[] senddata = r2000pcmd.GetSendCmd(R2000_calibration.R2000cmd.ENGTEST, et.ToByteData());

		MsgObj hMsg = new MsgObj(), hMsg2 = new MsgObj(), hMsg3 = new MsgObj(), hMsg4 = new MsgObj();

		@SuppressWarnings("unused")
		int re = SendandRev(senddata, 1000, hMsg);

		// frequency
		List<Byte> lb = new ArrayList<Byte>();
		lb.add((byte) 0);
		lb.add((byte) 0);
		lb.add((byte) 0);
		lb.add((byte) 0);

		byte[] bdata = R2000_calibration.intTobytes(915750);
		lb.addAll(R2000_calibration.bytesTolistbytes(bdata));

		senddata = r2000pcmd.GetSendCmd(R2000_calibration.R2000cmd.SetTestFre, R2000_calibration.ListBtobytes(lb));

		re = SendandRev(senddata, 1000, hMsg2);

		//

		senddata = r2000pcmd.GetSendCmd(R2000_calibration.R2000cmd.carrier, new byte[] { 0x01 });

		re = SendandRev(senddata, 1000, hMsg3);

		senddata = r2000pcmd.GetSendCmd(R2000_calibration.R2000cmd.carrier, new byte[] { 0x00 });

		re = SendandRev(senddata, 1000, hMsg4);
	}

	/**
	 * �����ز����Խӿڣ�API��
	 */
	public void testcarrywave_api() {
		READER_ERR er;
		int ant=1;
		int power=3000;
		int fre=918000;//�ձ�Ƶ�㣬��Ҫ���úø�����
		//�������ǹر�(1�ֽ�)+����id(1�ֽ�)+����(2�ֽ�)+Ƶ��(4�ֽ�)
		 Reader.CustomParam_ST cpst=Jreader.new CustomParam_ST();
		 cpst.ParamName="0";

         byte[] vals=new byte[9];
         int p=0;
			vals[p++]=0x01;
         vals[p++]=0x01;
			vals[p++]=(byte)ant;
			vals[p++]=(byte)((power&0xff00)>>8);
			vals[p++]=(byte)(power&0x00ff);
			vals[p++]=(byte)((fre&0xff000000)>>24);
			vals[p++]=(byte)((fre&0x00ff0000)>>16);
			vals[p++]=(byte)((fre&0x0000ff00)>>8);
			vals[p++]=(byte)(fre&0x000000ff);
         cpst.ParamVal=vals;
         er=Jreader.ParamSet(Mtr_Param.MTR_PARAM_CUSTOM,cpst);
			System.out.println("er:"+er.toString());
			cpst=Jreader.new CustomParam_ST();
			cpst.ParamName="0";
		 
			vals=new byte[9];
			p=0;
			vals[p++]=0x01;
			vals[p++]=0x00;
			vals[p++]=(byte)ant;
			vals[p++]=(byte)((power&0xff00)>>8);
			vals[p++]=(byte)(power&0x00ff);
			vals[p++]=(byte)((fre&0xff000000)>>24);
			vals[p++]=(byte)((fre&0x00ff0000)>>16);
			vals[p++]=(byte)((fre&0x0000ff00)>>8);
			vals[p++]=(byte)(fre&0x000000ff);
			cpst.ParamVal=vals;
			er=Jreader.ParamSet(Mtr_Param.MTR_PARAM_CUSTOM,cpst);
			System.out.println("er:"+er.toString());
	}
	
	
	/**
	 * �����¶ȱ�ǩ��led
	 */
	public void testtagtempratureled() {
		// *
		TagFilter_ST tfst = Jreader.new TagFilter_ST();
		tfst.bank = 1;
		tfst.fdata = new byte[] { (byte) 0xAA };
		// flen 0 Ϊȡ������
		tfst.flen = 8;
		tfst.isInvert = 0;
		tfst.startaddr = 32;
		TagFilter_ST tfst2 = Jreader.new TagFilter_ST();
		READER_ERR er;
		// er=Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_FILTER, tfst);
		er = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_FILTER, null);

		// */

		R2000_calibration.META_DATA rmeta = new R2000_calibration().new META_DATA();
		/*
		 * rmeta.IsAntennaID=true; rmeta.IsEmdData=true; rmeta.IsFrequency=true;
		 * rmeta.IsPro=true; rmeta.IsReadCnt=true; rmeta.IsRFU=true;
		 * rmeta.IsRSSI=true; rmeta.IsTimestamp=true;
		 */

		rmeta.IsAntennaID = false;
		rmeta.IsEmdData = false;
		rmeta.IsFrequency = false;
		rmeta.IsPro = false;
		rmeta.IsReadCnt = false;
		rmeta.IsRFU = false;
		rmeta.IsRSSI = false;
		rmeta.IsTimestamp = false;

		R2000_calibration.Tagtemperture_DATA tagtemp = new R2000_calibration().new Tagtemperture_DATA();
		er = Jreader.ReadTagTemperature(1, (char) 3, 0x7f, 1, 1100, 0, 100, rmeta.getMetaflag(), null, tagtemp);
		if (er == READER_ERR.MT_OK_ERR)
			System.out.println("testtempera:" + er.toString() + "  data:" + Reader.bytes_Hexstr(tagtemp.Data()));

		R2000_calibration.TagLED_DATA tagled = new R2000_calibration().new TagLED_DATA();
		er = Jreader.ReadTagLED(1, (short) 1000, rmeta.getMetaflag(), tagled);
		if (er == READER_ERR.MT_OK_ERR)
			System.out.println("testle:" + er.toString() + "   data:" + Reader.bytes_Hexstr(tagled.TagEpc()));
		
		String tag1="1111",tag2="EEEE";
		Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_MULTISELECTORS, new String[]{tag1,tag2});
		//ָ����������ʱ�䣬����metaflag|=0x8000;
		//ָ����������ʱ��ʱ����ʱ���㷽��   (�ܳ�ʱ=����ʱ��(���룩/100)<<8|����ʱ�䣨���룩/100
		int ledlighttime=3000,optime=500;
        int alltimeout = (ledlighttime/ 100) << 8|optime/ 100;
		er = Jreader.ReadTagLED(1, (short) alltimeout, (short)(rmeta.getMetaflag()|0x8000), tagled);
	}

	//��Ƶ�ز�����
	public void testVSWR() {
		AntPortsVSWR apvr = Jreader.new AntPortsVSWR();
		apvr.andid = 1;
		apvr.power = (short) 2000;
		apvr.region = Region_Conf.RG_NA;
		 //��Ƶ
		apvr.frecount = 1;
		apvr.vswrs[0].frequency = 915250;
		
		READER_ERR er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_RF_ANTPORTS_VSWR, apvr);
		
		if(er==READER_ERR.MT_OK_ERR)
		{
			String temp="";
			for(int i=0;i<apvr.frecount;i++)
			{
				temp+=apvr.vswrs[i].vswr+",";
			}
			
			System.out.println("VSWR:"+temp);
		}
	}
	
	//��Ƶ�ز�����
	public void testVSWR2() {
		 

			AntPortsVSWR apvr=Jreader.new AntPortsVSWR();
			apvr.andid=1;
			apvr.power=(short) 2000;
			Region_Conf[] rcf2 = new Region_Conf[1];
			READER_ERR er = Jreader.ParamGet(
					Mtr_Param.MTR_PARAM_FREQUENCY_REGION, rcf2);
			if (er == READER_ERR.MT_OK_ERR)
				apvr.region=rcf2[0];

			/*
			HoptableData_ST hdst2 = Jreader.new HoptableData_ST();
			er = Jreader.ParamGet(
					Mtr_Param.MTR_PARAM_FREQUENCY_HOPTABLE, hdst2);
			apvr.frecount=hdst2.lenhtb;
			for(int i=0;i<apvr.frecount;i++)
			{
				apvr.vswrs[i].frequency=hdst2.htb[i];
			}
			*/

			er=Jreader.ParamGet(Mtr_Param.MTR_PARAM_RF_ANTPORTS_VSWR, apvr);

		if(er==READER_ERR.MT_OK_ERR)
		{
			String temp="";
			for(int i=0;i<apvr.frecount;i++)
			{
				temp+=apvr.vswrs[i].vswr+",";
			}
			
			System.out.println("VSWR:"+temp);
		}
		 
	}
	
	/**
	 * ����LBT����
	 */
	public void testLBT() {
		AntPortsVSWR apvr = Jreader.new AntPortsVSWR();
		apvr.andid = 1;
		apvr.power = (short) 2000;
		apvr.region = Region_Conf.RG_NA;
		 //��Ƶ
		apvr.frecount = 1+256;
		apvr.vswrs[0].frequency = 915250;
		
		READER_ERR er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_RF_ANTPORTS_VSWR, apvr);
		if(er==READER_ERR.MT_OK_ERR)
		{
			String temp="";
			for(int i=0;i<apvr.frecount;i++)
			{
				temp+=String.valueOf(apvr.vswrs[i].vswr)+",";
			}
			
			System.out.println("lbt:"+temp);
		}
	}
	
			//bypass�Ĵ���  
	public void testbypassReg() {
		 
		 Reader.CustomParam_ST cpst=Jreader.new CustomParam_ST();
		 cpst.ParamName="0";
    
		 int addr=0x00000001;
         byte[] vals=new byte[5];
         
        
         int p=0;
			vals[p++]=(byte)0x03;
			vals[p++]=(byte)((addr&0xff000000)>>24);
			vals[p++]=(byte)((addr&0x00ff0000)>>16);
			vals[p++]=(byte)((addr&0x0000ff00)>>8);
			vals[p++]=(byte)(addr&0x000000ff);
         cpst.ParamVal=vals;
         READER_ERR er =Jreader.ParamGet(Mtr_Param.MTR_PARAM_CUSTOM,cpst);
         if(er==READER_ERR.MT_OK_ERR)
 		{
        	 byte[] val=new byte[4];
        	 for(int i=0;i<4;i++)
        	 val[i]=cpst.ParamVal[i];
        	 System.out.println("reg:"+Jreader.bytes_Hexstr(val));
 		}
        
	}
	
	 //oem�Ĵ���  
	public void testoemReg() {
		 Reader.CustomParam_ST cpst=Jreader.new CustomParam_ST();
		 cpst=Jreader.new CustomParam_ST();
		 cpst.ParamName="R2000/oemregister";
		 int addr=0x00000001;
		 cpst.ParamVal=new byte[4];
		 cpst.ParamVal[0]=(byte)((addr>>24)&0xff);
		 cpst.ParamVal[1]=(byte)((addr>>16)&0xff);
		 cpst.ParamVal[2]=(byte)((addr>>8)&0xff);
		 cpst.ParamVal[3]=(byte)(addr&0xff);
         READER_ERR er =Jreader.ParamGet(Mtr_Param.MTR_PARAM_CUSTOM,cpst);
         byte[] val=new byte[4];
         if(er==READER_ERR.MT_OK_ERR)
 		{
        	 for(int i=0;i<4;i++)
        	 val[i]=cpst.ParamVal[i];
        	 System.out.println("reg:"+Jreader.bytes_Hexstr(val));
 		}
         else
        	 return ;
      
         cpst.ParamVal=new byte[8];
         
		 cpst.ParamVal[0]=(byte)((addr>>24)&0xff);
		 cpst.ParamVal[1]=(byte)((addr>>16)&0xff);
		 cpst.ParamVal[2]=(byte)((addr>>8)&0xff);
		 cpst.ParamVal[3]=(byte)(addr&0xff);
		 cpst.ParamVal[4]=val[0];
		 cpst.ParamVal[5]=(byte) (val[1]==0x00?0x10:0x00);
		 cpst.ParamVal[6]=val[2];
		 cpst.ParamVal[7]=val[3];
		 
         Jreader.ParamSet(Mtr_Param.MTR_PARAM_CUSTOM,cpst);
         
        
         cpst.ParamVal=new byte[4];
		 cpst.ParamVal[0]=(byte)((addr>>24)&0xff);
		 cpst.ParamVal[1]=(byte)((addr>>16)&0xff);
		 cpst.ParamVal[2]=(byte)((addr>>8)&0xff);
		 cpst.ParamVal[3]=(byte)(addr&0xff);
         er =Jreader.ParamGet(Mtr_Param.MTR_PARAM_CUSTOM,cpst);
         if(er==READER_ERR.MT_OK_ERR)
 		{
        	  val=new byte[4];
        	 for(int i=0;i<4;i++)
        	 val[i]=cpst.ParamVal[i];
        	 System.out.println("reg:"+Jreader.bytes_Hexstr(val));
 		}
	}
	
	/**
	 * �����޸�EX��֤����
	 */
	private void testInitReg()
	{
		SpecObject val = Jreader.new SpecObject();
		Jreader.SpecParamsForReader(0, false, val);
		System.out.println("val:"+String.valueOf(val.Val()));
		
		SpecObject sval = Jreader.new SpecObject(Region_Conf.RG_PHILIPPINES);
		Jreader.SpecParamsForReader(0, true, sval);
		
		Jreader.SpecParamsForReader(0, false, val);
		System.out.println("val2:"+String.valueOf(val.Val()));
	}
	
	/**
	 * ��ȡ���ò���Ĭ��ֵ
	 */
	private void testgetdefvalue()
	{
		 READER_ERR er=READER_ERR.MT_OK_ERR;
		 er = Jreader.InitReader_Notype("com4", 4);
		 
		 AntPowerConf apcf2 = Jreader.new AntPowerConf();
		 er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_RF_ANTPOWER, apcf2);
			for (int i = 0; i < apcf2.antcnt; i++) {
				System.out.print("antid:" + apcf2.Powers[i].antid);
				System.out.print(" rp:" + apcf2.Powers[i].readPower);
				System.out.print(" wp:" + apcf2.Powers[i].writePower);
				System.out.println();
			}
			
		Region_Conf[] rcf2 = new Region_Conf[1];
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_FREQUENCY_REGION, rcf2);
		 System.out.println("region:"+String.valueOf(rcf2[0]));
        int[] val2=new int[1];
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_POTL_GEN2_Q, val2);
        System.out.println("Q:"+String.valueOf(val2[0]));

        val2[0] = 0;
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_POTL_GEN2_SESSION, val2);
		System.out.println("Session:"+String.valueOf(val2[0]));


	    val2[0] = 0;
		er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_POTL_GEN2_TARGET, val2);
		System.out.println("Target:"+String.valueOf(val2[0]));

	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("java.library.path:" + System.getProperty("java.library.path"));
		System.out.println("java.version:" + System.getProperty("java.version"));
		System.out.println("java.specification.version:" + System.getProperty("java.specification.version"));
		System.out.println("java.vm.name:" + System.getProperty("java.vm.name"));
		System.out.println("sun.arch.data.model:" + System.getProperty("sun.arch.data.model"));
		System.out.println("os.arch:" + System.getProperty("os.arch"));

		// *  windows ƽ̨��Ҫ������Щ������dll��
		try {
			if (!System.getProperty("os.arch").contains("64")) {
				// 32λϵͳ��Ҫ���֧�ֿ�
				System.loadLibrary("ACE");
			
			}
			System.loadLibrary("PCOMM");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		maintest_std mt = new maintest_std();

		//mt.testgetdefvalue();
		
		// ���Գ�ʼ��
		JOptionPane.showMessageDialog(null, "ready to connect", "��Ϣ��ʾ", JOptionPane.INFORMATION_MESSAGE);
 
		if (!mt.testinitreader())
			return;
		
		//īˮƿ
		mt.testfilterwirteandread();
		
		//mt.testdefaultvalue();
		//mt.testInitReg();
		
		//�����ز�api
		//mt.testcarrywave_api();
		//����Ĭ��ֵ
		//mt.testdefaultvalue();
		
		// ����ת��
		// mt.testtran();
		
		// ����gpio
		// mt.testgpio();
		
		// ���Բ���
		//  mt.testrparams();
		
		// ���Կ����
		// mt.testblockop();
		
		// ��������ָ��
		// mt.testcustomcmd();
		
		// ���Զ�д���ڲ�����
		// mt.testdataonreader();
		
		// �����̵㷽ʽ1--�Ѳ���
		//  mt.testinventory1();
		
		// �����̵㷽ʽ2---��ͨģʽ
		// mt.testinventory2();
		
		// �����̵㷽ʽ3
		// mt.testinventory3();
		
		// ����Ƕ���̵�3
		// mt.testinventory3_emddata();
		
		// ������������
		// mt.testkilltag();
		
		// ��������ǩ
		// mt.testlocktag();
		
		// ���Զ�д��ǩ
		// mt.testreadandwrite();
		
		// ���Զ������������д��ǩ
		// mt.writeData(...);
		
		// ���Ը�ip��ַ
		// mt.testsetip();
		
		// �����޸�Ĭ�Ϲ���
		// mt.testdefaultbaudrate();
		
		// ���Ի�ȡmac
	   // mt.testgetmac();
		
		// ����psam
		// mt.testpsam();
		
		// �����ز�����
		// mt.testcarrywave();

		// ��������פ��
		//mt.testVSWR();
		
		//mt.testVSWR2();
		 
		 // ����������д��
		// mt.testLBT();
		
		// �����¶ȱ�ǩ
		// mt.testtagtempratureled();

		// �����ϴδ���ԭ��
		// mt.testerrinfo();
		
		//���Ի�ȡoem�Ĵ���ֵ
		 //mt.testoemReg();
		
		// �رն�д��
		mt.Jreader.CloseReader();
		System.out.println("test over");
	}

}
