﻿package demo.mulreaders;

import com.uhf.api.cls.BackReadOption;
import com.uhf.api.cls.ReadExceptionListener;
import com.uhf.api.cls.ReadListener;
import com.uhf.api.cls.Reader;
import com.uhf.api.cls.Reader.AntPower;
import com.uhf.api.cls.Reader.AntPowerConf;
import com.uhf.api.cls.Reader.ConnAnts_ST;
import com.uhf.api.cls.Reader.Inv_Potl;
import com.uhf.api.cls.Reader.Inv_Potls_ST;
import com.uhf.api.cls.Reader.Mtr_Param;
import com.uhf.api.cls.Reader.READER_ERR;
import com.uhf.api.cls.Reader.SL_TagProtocol;
import com.uhf.api.cls.Reader.TAGINFO;
/**
* 事件方式启动多个读写器
* @author Administrator
*
*/
public class maintest_mulevent extends Thread {

	/**
	 * @param args
	 */

	public int antport = 4;// 天线端口
	public String addr = "//./com19";// "/dev/ttyMT0";"192.168.1.100"
	Reader Jreader;
	int Id = 0;

	public maintest_mulevent() {
		
	}
	
	public READER_ERR startReadTags() {
		// 初始化结BackReadOption
		BackReadOption m_BROption = new BackReadOption();
		// 本例只使用天线1进行盘存，如果要使用多个天线则只需要将使用的天线编
		// 号赋值到数组ants中，例如同时使用天线1和2，则代码应该改为ants[0] = 1;
		// ants[1] = 2;antcnt = 2;
		int[] uant;// 盘点天线

		ConnAnts_ST val = Jreader.new ConnAnts_ST();
		READER_ERR er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_READER_CONN_ANTS, val);
		if (er == READER_ERR.MT_OK_ERR && val.antcnt > 0) {
			uant = new int[val.antcnt];
			for (int i = 0; i < val.antcnt; i++)
				uant[i] = val.connectedants[i];
		} else {
			uant = new int[] { 1 };

		}
		System.out.print("id:" + Id + " " + "ants:");
		for (int i = 0; i < uant.length; i++)
			System.out.print(uant[i] + " ");
		System.out.println();
		/*
		 * 是否采用高速模式（目前只有slr11xx和slr12xx系列读写器才支持）,对于
		 * 一般标签数量不大，速度不快的应用没有必要使用高速模式,本例没有设置 使用高速模式
		 */
		m_BROption.IsFastRead = true;// 采用非高速模式盘存标签

		/// 非高速盘存模式下必须要设置的参数*******************************************
		// 盘存周期,单位为ms，可根据实际使用的天线个数按照每个天线需要200ms
		// 的方式计算得出,如果启用高速模式则此选项没有任何意义，可以设置为
		// 任意值，或者干脆不设置
		m_BROption.ReadDuration = (short) (200 * uant.length);
		// 盘存周期间的设备不工作时间,单位为ms,一般可设置为0，增加设备不工作
		// 时间有利于节电和减少设备发热（针对某些使用电池供电或空间结构不利
		// 于散热的情况会有帮助）
		m_BROption.ReadInterval = 0;
		// ****************************************************************************

		// 高速盘存模式参数设置********************************************************
		// 以下为选择使用高速模式才起作用的选项参,照如下设置即可,如果使能高速
		// 模式，即把IsFastRead设置为true则,只需取消以下被注释的代码即可
		
		 //高速模式下为取得最佳效果设置为0即可 
		m_BROption.FastReadDutyRation = 0;
		 //标签信息是否携带识别天线的编号 
		m_BROption.TMFlags.IsAntennaID = true;
		 //标签信息是否携带标签识别次数 
		m_BROption.TMFlags.IsReadCnt = false;
		 //标签信息是否携带识别标签时的信号强度 
		m_BROption.TMFlags.IsRSSI = false; //标签信息是否携带时间戳
		 m_BROption.TMFlags.IsTimestamp = false; //标签信息是否携带识别标签时的工作频点
		 m_BROption.TMFlags.IsFrequency = false;
		 //标签信息是否携带识别标签时同时读取的其它bank数据信息,如果要获取在
		 //盘存时同时读取其它bank的信息还必须设置MTR_PARAM_TAG_EMBEDEDDATA参数,
		 //（目前只有slr11xx和slr12xx系列读写器才支持）
		 m_BROption.TMFlags.IsEmdData = false;
		 //保留字段，可始终设置为0 
		 m_BROption.TMFlags.IsRFU = false;
		 
		// ****************************************************************************
		//设置盘存到标签时的回调处理函数                                           
		 Jreader.addReadListener(RL);
			//*
	 	//设置读写器发生错误时的回调处理函数                                       
		 Jreader.addReadExceptionListener(REL);   

		 return Jreader.StartReading(uant, uant.length, m_BROption);
	     
	}

	ReadListener RL = new ReadListener() {
		@Override
		public void tagRead(Reader r, final TAGINFO[] tag) {
			// TODO Auto-generated method stub

			for (int i = 0; i < tag.length; i++) {
				if (tag[i].EmbededDatalen == 0)
					System.out.println("event id:" + Id + " " + Reader.bytes_Hexstr(tag[i].EpcId));
				else
					System.out.println("event id:" + Id + " " + Reader.bytes_Hexstr(tag[i].EpcId) + " "
							+ Reader.bytes_Hexstr(tag[i].EmbededData));
			}

		}

	};

	ReadExceptionListener REL = new ReadExceptionListener() {

		@Override
		public void tagReadException(Reader r, final READER_ERR re) {

			// 如果需要可在此处记录异常日志
			System.out.println("id:" + Id + " " +r.GetReaderAddress() + "--异常信息:" + re.toString());
		}
	};

	public boolean testinitreader() {
		Jreader = new Reader();
		READER_ERR err = Jreader.InitReader_Notype(addr, antport);
		System.out.println("id:" + Id + " connect reader:" + String.valueOf(err));
		if (err != READER_ERR.MT_OK_ERR)
			return false;
		Inv_Potls_ST ipst = Jreader.new Inv_Potls_ST();
		ipst.potlcnt = 1;
		ipst.potls = new Inv_Potl[ipst.potlcnt];
		for (int i = 0; i < ipst.potlcnt; i++) {
			Inv_Potl ipl = Jreader.new Inv_Potl();
			ipl.weight = 30;
			ipl.potl = SL_TagProtocol.SL_TAG_PROTOCOL_GEN2;
			ipst.potls[i] = ipl;
		}
		//设置协议，可省略，现仅仅支持gen2协议
		 err = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_INVPOTL, ipst);
		//检测天线
		 err = Jreader.ParamSet(Mtr_Param.MTR_PARAM_READER_IS_CHK_ANT, new int[] { 1 });
		 //设置Session1
		 err = Jreader.ParamSet(Mtr_Param.MTR_PARAM_POTL_GEN2_SESSION, new int[] { 1 });

		int[] mp = new int[1];
		err = Jreader.ParamGet(Mtr_Param.MTR_PARAM_RF_MAXPOWER, mp);
		if (err == READER_ERR.MT_OK_ERR) {
			AntPowerConf apcf = Jreader.new AntPowerConf();
			apcf.antcnt = antport;
			for (int i = 0; i < apcf.antcnt; i++) {
				AntPower jaap = Jreader.new AntPower();
				jaap.antid = i + 1;
				jaap.readPower = (short) (mp[0]);
				jaap.writePower = (short) (mp[0]);
				apcf.Powers[i] = jaap;
			}
			err = Jreader.ParamSet(Mtr_Param.MTR_PARAM_RF_ANTPOWER, apcf);
		}
		return true;
	}

	@Override
	public void run() {
		 
		READER_ERR er = READER_ERR.MT_OK_ERR;
		//testinitreader();
		//startReadTags();
		long st = System.currentTimeMillis();
		while (true) {

			//int[] tagcnt = new int[1];
			//er = Jreader.AsyncGetTagCount(tagcnt);
			//System.out.println("id:" + Id + " " + String.valueOf(tagcnt[0]));
			
			if (System.currentTimeMillis() - st > 3000) {
				System.out.println("id:" + Id + " " + "stop asyn read");
				//停止读标签并且关闭读写器
				er = Jreader.StopReading();
				Jreader.CloseReader();
				break;
			} else {
				 
				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		
		return;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("java.library.path:" + System.getProperty("java.library.path"));
		System.out.println("java.version:" + System.getProperty("java.version"));
		System.out.println("java.specification.version:" + System.getProperty("java.specification.version"));
		System.out.println("java.vm.name:" + System.getProperty("java.vm.name"));
		System.out.println("sun.arch.data.model:" + System.getProperty("sun.arch.data.model"));
		System.out.println("os.arch:" + System.getProperty("os.arch"));

		// *  windows 平台需要加载这些第三方dll库
		// *
		try {
			if(!System.getProperty("os.arch").contains("64"))
			{ 
			   //32位系统需要这个支持库
			System.loadLibrary("ACE");
			
			}
		   System.loadLibrary("PCOMM");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// */

		// 测试初始化
		// JOptionPane.showMessageDialog(null, "ready to connect", "消息提示",
		// JOptionPane.INFORMATION_MESSAGE);

		String[] addrs = new String[] { "192.168.1.168", "com4" };
		int[] ports = new int[] { 16,4 };
	 
		for (int i = 0; i < addrs.length; i++) {
			maintest_mulevent mt = new maintest_mulevent();
			mt.Id = i + 1;
			mt.addr = addrs[i];
			mt.antport = ports[i];
  
			// 事件模式
			mt.testinitreader();
			mt.startReadTags();
			mt.start();
		}
 
		
	}

}
