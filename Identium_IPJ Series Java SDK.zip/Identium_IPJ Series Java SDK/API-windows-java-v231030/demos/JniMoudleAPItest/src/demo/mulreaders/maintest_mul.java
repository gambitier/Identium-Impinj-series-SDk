﻿package demo.mulreaders;

import com.uhf.api.cls.Reader;
import com.uhf.api.cls.Reader.AntPower;
import com.uhf.api.cls.Reader.AntPowerConf;
import com.uhf.api.cls.Reader.ConnAnts_ST;
import com.uhf.api.cls.Reader.HardwareDetails;
import com.uhf.api.cls.Reader.Inv_Potl;
import com.uhf.api.cls.Reader.Inv_Potls_ST;
import com.uhf.api.cls.Reader.Mtr_Param;
import com.uhf.api.cls.Reader.READER_ERR;
import com.uhf.api.cls.Reader.ReaderVersion;
import com.uhf.api.cls.Reader.SL_TagProtocol;
import com.uhf.api.cls.Reader.TAGINFO;

/**
 * 线程方式启动多个读写器
 * @author Administrator
 *
 */
public class maintest_mul extends Thread {
	/**
	 * @param args
	 */
	public int antport = 4;// 天线端口
	public String addr = "//./com19";// "/dev/ttyMT0";"192.168.1.100"
	Reader Jreader;
    public boolean Tagevnt=false;
	int Id = 0;

	public maintest_mul() {
		
	}

	public READER_ERR startReadTags() {

		int[] uant;// 盘点天线

		ConnAnts_ST val = Jreader.new ConnAnts_ST();
		//获取已连接天线
		READER_ERR er = Jreader.ParamGet(Mtr_Param.MTR_PARAM_READER_CONN_ANTS, val);
		if (er == READER_ERR.MT_OK_ERR && val.antcnt > 0) {
			uant = new int[val.antcnt];
			for (int i = 0; i < val.antcnt; i++)
				uant[i] = val.connectedants[i];
		} else {
			uant = new int[] { 1 };

		}
		System.out.print("id:" + Id + " " + "ants:");
		for (int i = 0; i < uant.length; i++)
			System.out.print(uant[i] + " ");
		System.out.println();
		//启动快速模式
		READER_ERR readerErr = Jreader.AsyncStartReading(uant, uant.length, 1152);
		return readerErr;
	}
 
	public boolean testinitreader() {
		Jreader = new Reader();
		READER_ERR err = Jreader.InitReader_Notype(addr, antport);
		System.out.println("initreader:"+err.toString());
		if (err != READER_ERR.MT_OK_ERR)
			return false;
		
		//获取硬件信息
				HardwareDetails val = Jreader.new HardwareDetails();
				err = Jreader.GetHardwareDetails(val);
				//获取版本信息
				ReaderVersion rdrver = Jreader.new ReaderVersion();
				Jreader.ParamGet(Mtr_Param.MTR_PARAM_READER_VERSION, rdrver);

				System.out.println("module:" + val.module.toString() + "\r\nsoftwareVer:" +
						rdrver.softwareVer + "\r\nhardwareVer:" + rdrver.hardwareVer);
				
		Inv_Potls_ST ipst = Jreader.new Inv_Potls_ST();
		ipst.potlcnt = 1;
		ipst.potls = new Inv_Potl[ipst.potlcnt];
		for (int i = 0; i < ipst.potlcnt; i++) {
			Inv_Potl ipl = Jreader.new Inv_Potl();
			ipl.weight = 30;
			ipl.potl = SL_TagProtocol.SL_TAG_PROTOCOL_GEN2;
			ipst.potls[i] = ipl;
		}
		//设置协议，可省略，现仅仅支持gen2协议
		err = Jreader.ParamSet(Mtr_Param.MTR_PARAM_TAG_INVPOTL, ipst);

		//检测天线
		err = Jreader.ParamSet(Mtr_Param.MTR_PARAM_READER_IS_CHK_ANT, new int[] { 1 });
        //设置Session1
		err = Jreader.ParamSet(Mtr_Param.MTR_PARAM_POTL_GEN2_SESSION, new int[] { 1 });

		//先获取允许最大功率值再设置功率
		int[] mp = new int[1];
		err = Jreader.ParamGet(Mtr_Param.MTR_PARAM_RF_MAXPOWER, mp);
		if (err == READER_ERR.MT_OK_ERR) {
			AntPowerConf apcf = Jreader.new AntPowerConf();
			apcf.antcnt = antport;
			int[] rpow = new int[apcf.antcnt];
			int[] wpow = new int[apcf.antcnt];
			for (int i = 0; i < apcf.antcnt; i++) {
				AntPower jaap = Jreader.new AntPower();
				jaap.antid = i + 1;
				jaap.readPower = (short) (mp[0]);
				rpow[i] = jaap.readPower;

				jaap.writePower = (short) (mp[0]);
				wpow[i] = jaap.writePower;
				apcf.Powers[i] = jaap;
			}
			err = Jreader.ParamSet(Mtr_Param.MTR_PARAM_RF_ANTPOWER, apcf);
		}
		return true;
	}

	@Override
	public void run() {
	
		/*
		 testinitreader();
		 READER_ERR er = startReadTags();
		if (er != Reader.READER_ERR.MT_OK_ERR) {
			System.out.println("id:" + Id + " " + "start asyn read failed");
			return;
		}
		*/
		
		 READER_ERR er =READER_ERR.MT_OK_ERR; 
		
		long st = System.currentTimeMillis();
		while (true) {

			if (System.currentTimeMillis() - st > 3000) {
				System.out.println("id:" + Id + " " + "stop asyn read");
				//停止快速模式
				er = Jreader.AsyncStopReading();
				int[] val=new int[1];
				Jreader.CloseReader();
				break;
			} else {

				int[] tagcnt = new int[1];
				//获取快速模式下缓冲标签个数
				er = Jreader.AsyncGetTagCount(tagcnt);
				if (er == Reader.READER_ERR.MT_OK_ERR) {
					System.out.println("id:" + Id + " tag:"+String.valueOf(tagcnt[0]));
					if (tagcnt[0] > 0) {
						for (int i = 0; i < tagcnt[0]; i++) {
							TAGINFO ti = Jreader.new TAGINFO();
							//获取快速模式下，当前一个标签
							er = Jreader.AsyncGetNextTag(ti);
							if (er == Reader.READER_ERR.MT_OK_ERR)
								System.out.println("id:" + Id + " " + String.valueOf(System.currentTimeMillis() - st)
										+ " " + Reader.bytes_Hexstr(ti.EpcId) + " antid:" + ti.AntennaID);
						}
					}
				} else
					System.out.println("id:" + Id + " " + er.toString());

				try {
					Thread.sleep(50);
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}

		}
		
		System.out.println("id:" + Id + " finish " + String.valueOf(System.currentTimeMillis() - st));
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("java.library.path:" + System.getProperty("java.library.path"));
		System.out.println("java.version:" + System.getProperty("java.version"));
		System.out.println("java.specification.version:" + System.getProperty("java.specification.version"));
		System.out.println("java.vm.name:" + System.getProperty("java.vm.name"));
		System.out.println("sun.arch.data.model:" + System.getProperty("sun.arch.data.model"));
		System.out.println("os.arch:" + System.getProperty("os.arch"));

		// *  windows 平台需要加载这些第三方dll库
		// *
		try {
			if(!System.getProperty("os.arch").contains("64"))
			{ 
			   //32位系统需要这个支持库
			System.loadLibrary("ACE");
			
			}
		   System.loadLibrary("PCOMM");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// */

		// 测试初始化
		// JOptionPane.showMessageDialog(null, "ready to connect", "消息提示",
		// JOptionPane.INFORMATION_MESSAGE);

		/*String[] addrs = new String[] { "192.168.1.168", "com4" };
		int[] ports = new int[] { 16, 4 };*/
		
		String[] addrs = new String[] {"com80" };
		int[] ports = new int[] { 16};
		
		for (int i = 0; i < addrs.length; i++) {
			maintest_mul mt = new maintest_mul();
			mt.Id = i + 1;
			mt.addr = addrs[i];
			mt.antport = ports[i];
		 
			// 线程模式
			mt.testinitreader();
			mt.startReadTags();
			mt.start();
			 
		}
		
		System.out.println("main exit");
	}

}
