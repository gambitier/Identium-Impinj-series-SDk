package demo.gpiquick;
import com.uhf.api.cls.GpiInfo_ST;
import com.uhf.api.cls.Reader;

/**
 * @author mjl-pc
 */

public class LongTermAsyncRead {

    private volatile Reader rdr = null;
    private volatile boolean running = false;

    public Reader.READER_ERR openReader() {
        Reader.READER_ERR err;
        //����д����Ϊ�����ȹرն�д�����ÿ�
        if (rdr != null) {
            rdr.CloseReader();
            rdr = null;
        }
        
        rdr = new Reader();
        int portnum = 16;
        //�򿪶�д��
        err = rdr.InitReader_Notype("192.168.1.168", portnum);
        if (err != Reader.READER_ERR.MT_OK_ERR) {
            return err;
        }
        
        int[] maxpower = new int[1];
        //��ȡ�������õ������ֵ
        err = rdr.ParamGet(Reader.Mtr_Param.MTR_PARAM_RF_MAXPOWER, maxpower);
        if (err != Reader.READER_ERR.MT_OK_ERR) {
            return err;
        }
        Reader.AntPowerConf apcf = rdr.new AntPowerConf();
        apcf.antcnt = portnum;
        for (int i = 0; i < apcf.antcnt; i++) {
            Reader.AntPower jaap = rdr.new AntPower();
            jaap.antid = i + 1;
            jaap.readPower = (short) 2000;
            jaap.writePower = (short) 2000;
            apcf.Powers[i] = jaap;
        }
        
        Reader.Inv_Potls_ST ipst = rdr.new Inv_Potls_ST();
        ipst.potlcnt = 1;
        ipst.potls = new Reader.Inv_Potl[1];
        for (int i = 0; i < ipst.potlcnt; i++) {
            Reader.Inv_Potl ipl = rdr.new Inv_Potl();
            ipl.weight = 30;
            ipl.potl = Reader.SL_TagProtocol.SL_TAG_PROTOCOL_GEN2;
            ipst.potls[0] = ipl;
        }
      //����Э�飬��ʡ�ԣ��ֽ���֧��gen2Э��
        return rdr.ParamSet(Reader.Mtr_Param.MTR_PARAM_TAG_INVPOTL, ipst);
    }

    public void startReadTags() {

        int antcnt = 1;
        int[] ants = new int[antcnt];
        ants[0] = 1;
      //��������ģʽ
        Reader.READER_ERR readerErr = rdr.AsyncStartReading(ants, antcnt, 0);
        if (readerErr == Reader.READER_ERR.MT_OK_ERR) {
            running = true;
        }
    }

    private void checkGpi() {
        
       
        GpiInfo_ST gpist=new GpiInfo_ST();
        //arm7�豸���̵���ͬʱ��ȡgpi��ʹ�øýӿڻ�ȡ����gpi״̬
		Reader.READER_ERR readerErr1 = rdr.GetGPIEx(gpist);
		if (readerErr1 == Reader.READER_ERR.MT_OK_ERR){
        for(int i=0;i<gpist.gpiCount;i++)
        System.out.println("get gpi>>>>" + (gpist.gpiStats[i].GpiId) + ":" 
        + gpist.gpiStats[i].State);
            
        }
    }

    private void readLabel() {
        
        int[] tagcnt = new int[1];
        Reader.READER_ERR er = rdr.AsyncGetTagCount(tagcnt);
        if (er == Reader.READER_ERR.MT_OK_ERR) {
            if (tagcnt[0] > 0) {
                String[] tag = new String[tagcnt[0]];
                for (int i = 0; i < tagcnt[0]; i++) {
                    Reader.TAGINFO tfs = rdr.new TAGINFO();
                  //��ȡ����ģʽ�»����ǩ����
                    er = rdr.AsyncGetNextTag(tfs);
                    if (er == Reader.READER_ERR.MT_HARDWARE_ALERT_ERR_BY_TOO_MANY_RESET) {
                        break;
                    }
                    if (er != Reader.READER_ERR.MT_OK_ERR) {
                        break;
                    }
                    tag[i] = Reader.bytes_Hexstr(tfs.EpcId);
                    System.out.println(tag[i]);
                }
            }
           
        }
    }

   
    public void checkGpiAndReadTask() {
         
           
                try {
                    checkGpi();
                    readLabel();
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
        
    }

   
    public Reader.READER_ERR stopReadTask() {
        if (!running) {
            return Reader.READER_ERR.MT_OK_ERR;
        }
        //ֹͣ����ģʽ�̵�
        Reader.READER_ERR er = rdr.AsyncStopReading();
        if (er == Reader.READER_ERR.MT_OK_ERR) {
            running = false;
           
        }
        return er;
    }
}
