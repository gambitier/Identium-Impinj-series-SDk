package demo.gpiquick;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.uhf.api.cls.Reader;
import com.uhf.api.cls.Reader.*;
 
/*
 *  arm7,arm9 �豸�����ڿ���ģʽ�²�ѯgpi״̬
 * 
 */

public class maintest_gpiqik extends Thread{

	/**
	 * @param args
	 */
	 
	public maintest_gpiqik(){}
	
	@Override
	public void run()
	{
		 
		LongTermAsyncRead lar=new LongTermAsyncRead();
		boolean init=true;
		long st=System.currentTimeMillis();
		while(true)
		{
			
			if(init)//��ʼ���򿪶�д������ʼ�̵�
			{ lar.openReader();lar.startReadTags();init=false;}
			
		    lar.checkGpiAndReadTask();//���gpi����
		    
		    if(System.currentTimeMillis()-st>1000*10)
		    	break;
		}
		lar.stopReadTask();//��������
	}
	 
	public static void main(String[] args) {
		 
		System.out.println("java.library.path:"+System.getProperty("java.library.path"));
		System.out.println("java.version:"+System.getProperty("java.version"));
		System.out.println("java.specification.version:"+System.getProperty("java.specification.version"));
		System.out.println("java.vm.name:"+System.getProperty("java.vm.name"));
		System.out.println("sun.arch.data.model:"+System.getProperty("sun.arch.data.model"));
		System.out.println("os.arch:"+System.getProperty("os.arch"));
		
		// *  windows ƽ̨��Ҫ������Щ������dll��
		try {
			if(!System.getProperty("os.arch").contains("64"))
			{ 
			   //32λϵͳ��Ҫ���֧�ֿ�
			System.loadLibrary("ACE");
			
			}
		   System.loadLibrary("PCOMM");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		maintest_gpiqik mt=new maintest_gpiqik();
		mt.start();
	}
	 
}
